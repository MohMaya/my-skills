# Workflow/Notion.md

Load when the task touches durable knowledge: specs, PRDs, research notes, decision docs, or anything that should outlive the session.

## Division of record

Linear tracks work; Notion holds why. Issue state, assignees, and status live in Linear. Context, specs, PRDs, research, and decisions live in Notion. Do not duplicate one into the other -- link.

## Where things land

- Specs publish through `to-spec`, PRDs through `writing-prds` -- both after a `grilling` pass -- then land as Notion pages.
- Research output from the `research` skill lands in Notion when it should outlive the repo.
- One page per concern. Update in place; do not spawn near-duplicate pages.

## Tooling

Use the Notion MCP tools (notion plugin) to search, read, create, and update pages. Search before creating -- the page probably exists. Link Linear issues to their Notion pages and back.
