# Workflow/Delivery.md

Load for CI/CD, runtime safety, observability, rollback, feature flags, and delivery gates.

## Pipeline baseline

Every production path should have these stages:

1. format or lint
2. static checks or type checks
3. tests
4. security scan
5. build
6. deploy gate

Failing quality gates block merge or deploy.

Skill gates: `security-review` on auth-touching changes and before any launch; E2E via `playwright-best-practices` and `playwright-cli`; backend deploys through `use-railway`; mobile pipelines through `eas-workflows` and `eas-app-stores`.

## Pre-commit minimum

Use a pre-commit layer that covers:
- formatting
- lint
- fast tests or smoke checks
- type checking when the stack supports it

## Observability baseline

### Logging

- structured logs
- consistent levels
- request or trace identifiers
- operation name and duration where it matters
- never log secrets or PII

### Metrics

Minimum runtime metrics:
- request count
- error count
- latency distribution
- resource saturation

### Error tracking

Unhandled exceptions should land in a central error tracker with enough context to debug the failure.

## Rollback policy

Rollback when:
- error rate spikes hard after deploy
- P0 behavior appears in production
- performance regresses materially
- data integrity is threatened

Rules:
- rollback should be one command or one obvious platform action
- schema changes must be backward-compatible with the previous app version
- do not treat destructive migration rollback as routine

## Feature flags

Use flags for:
- risky rollouts
- incomplete but mergeable work
- percentage or allowlist rollouts

Rules:
- every flag has an owner
- every flag has an expiry date
- cleanup is tracked work
- flag checks live in service or application logic, not presentation

## Caching

Cache only when the consistency tradeoff is acceptable.

Rules:
- explicit invalidation for mutable data
- versioned keys
- TTL on every cache entry
- safe cache-miss behavior
- cache logic lives in service or data layers

## ADR linkage

If delivery or rollout constraints force a durable change in architecture, capture it with an ADR using the format in `Core/Documents.md`.
