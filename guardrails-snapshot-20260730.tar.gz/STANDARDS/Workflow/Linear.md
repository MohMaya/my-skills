# Workflow/Linear.md

Load when Linear is the system of record for work tracking.

## When Linear is primary

Use Linear issue keys in:
- branch names
- commit subjects
- PR titles or first line of PR body

Preferred commit pattern:

`TICKET-123: Imperative description`

## Issue hygiene

A usable issue has:
- clear summary: `TICKET-123: Imperative description`
- context or problem statement
- concrete requirements or acceptance criteria
- owner when active
- links to related PRs or docs

## Branch and PR linkage

Preferred branch pattern:

`sc/TICKET-123-short-description`

Preferred PR opening line:

`TICKET-123: What changed and why`

Close the loop by linking the PR back to the Linear issue and using the closing syntax your repo expects.

## Workflow expectations

- do not start vague tickets blind
- tighten the ticket before coding if the ambiguity would cause rework
- keep large efforts broken into smaller issues
- treat cleanup for feature flags and follow-ups as tracked work, not oral tradition

## Skill guidance

- No ticket filed without at least one `grilling` pass on the plan.
- File tickets through `to-tickets` and specs through `to-spec`, never hand-written.
- Multi-session efforts run through `wayfinder`; execution from tickets through `implement`.
- Use the Linear MCP tools (linear plugin) for reading, creating, and updating issues or projects -- issue state lives in the tracker, not in prose.
