# STANDARDS/INDEX.md

This folder is the operating system. `AGENTS.md` is only the kernel.

## Structure

| Area | Owns |
| ---- | ---- |
| `Core/` | How the agent codes, executes, plans, writes, and structures documents |
| `Skills/` | When to invoke skills and the installed skill inventory |
| `Workflow/` | Git, CI/CD, tracker workflow, review flow, and runtime rules |
| `Stack/` | Language and framework rules |
| `Product/` | Product-specific architecture and domain doctrine |

## Load order

1. Start with the matching `Core/` file.
2. Add the relevant `Workflow/` file if the task touches process or delivery.
3. Add the relevant `Stack/` file if the task touches a language or framework.
4. Add `Product/` only if the task is product-architecture specific.
5. Use `Skills/Routing.md` whenever a skill could help.

## Ownership rule

One concern, one owner.

- Craft doctrine -- the sources behind the kernel's discipline -- lives in `Core/Craft.md`.
- Code quality and layering live in `Core/Code.md`.
- Execution behavior lives in `Core/Execution.md`.
- Planning quality lives in `Core/Planning.md`.
- Default tone lives in `Core/Prose.md`.
- Document shapes live in `Core/Documents.md`.
- Skill routing lives in `Skills/Routing.md`.
- Git and PR rules live in `Workflow/Git.md`.
- Delivery, observability, rollback, flags, and runtime safety live in `Workflow/Delivery.md`.
- Tracker-specific doctrine lives in the tracker file under `Workflow/`.
- Stack rules live under `Stack/`.
- Product architecture lives in `Product/Architecture.md`.

If two files start teaching the same thing, the tree is drifting. Collapse it.

## Rewrite rule

Do not add a new standards file until you can explain why the concern cannot live cleanly inside an existing owner. Flat sprawl is just as bad as one giant constitution.
