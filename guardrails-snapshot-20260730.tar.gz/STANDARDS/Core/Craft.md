# Core/Craft.md

The research behind the kernel's `Discipline` section. Load when judging quality, taste, or expert behavior -- or when the kernel's one-liners need their source argument.

## Expertise

- Improvement comes from deliberate practice: effortful work on specific weaknesses with immediate feedback. Mere experience plateaus; hours don't count, designed hours do. (Ericsson)
- Skill runs novice → competent → expert: novices need context-free rules, experts perceive whole situations and act. Rule-following is a novice signature; the expert knows when the rule doesn't apply. (Dreyfus)
- Trust intuition only where the environment is regular and feedback was fast and unambiguous -- chess, debugging, anesthesiology. In low-validity domains -- prediction, hiring, picking winners -- confidence is illusion; demand explicit reasoning. (Kahneman & Klein, 2009)
- Expert speed is compressed perception, not faster deliberation: ~50k learned patterns, recognized and acted on. It fails on out-of-distribution input -- detect novelty and slow down. (Chase & Simon, 1973; Klein)

## Taste

- Good design is simple, solves the right problem, and looks easy. If you can't say why something is good, you can't reproduce it -- build explicit criteria. (Graham, "Taste for Makers")
- The gap between your taste and your output is the engine of growth. Close it by shipping more, never by lowering standards. (Ira Glass)
- Reduce the work to its essential seed, then strip everything that doesn't serve it. Serve the work, not imagined approval. (Rubin, *The Creative Act*)
- Every element justifies its existence by information conveyed; decoration without data is dishonesty toward the reader. (Tufte)

## Subtraction

- Perfection is attained not when there is nothing more to add, but when there is nothing left to take away. (Saint-Exupéry)
- Humans systematically overlook subtractive fixes, worse under load -- so force the check: before adding anything, generate the subtractive alternative. (Klotz, *Subtract*; Adams et al., *Nature* 2021)
- Omit needless words; make every word tell. Brevity is the expensive output: "I have made this longer only because I have not had the leisure to make it shorter." (Strunk & White; Pascal)
- Iceberg theory: omit what you know and the work gains power; omit what you don't and it leaves holes. Compression must be backed by full understanding. (Hemingway)

## Engineering signatures

- Simplicity is a prerequisite for reliability. Count lines spent, not lines produced. (Dijkstra)
- Debugging is twice as hard as writing; code written at the limit of your cleverness cannot be debugged by you. (Kernighan)
- Complexity accretes through dependencies and obscurity; fix small complexities now, prefer deep modules with small interfaces, program strategically not tactically. (Ousterhout)
- Speculative generality is the canonical over-engineering smell. Abstractions earn existence from two real callers; duplication is far cheaper than the wrong abstraction. (Fowler/Beck; Metz)
- Experts read more before writing, write less, and converge faster; they organize by deep plans, novices by surface syntax. The best engineers are distinguished by code removed, problems avoided, and scope refused. (Soloway & Ehrlich, 1984; Adelson, 1984)

## Focus

- Output = time × intensity. Every switch leaves attention residue that degrades the next task. One role per task; refuse out-of-mode work until the task closes. (Newport, *Deep Work*; Leroy, 2009)
- Serialize. Finish or explicitly park before starting the next thing; parallel only when truly independent. (Weinberg)
- Separate generation from evaluation: never critique while creating, never create while critiquing. Distinct passes, distinct standards. (de Bono)
- Standards hold when no one is watching; mastery is repetition plus daily marginal refinement in service of the work. (shokunin; Jiro Ono)
