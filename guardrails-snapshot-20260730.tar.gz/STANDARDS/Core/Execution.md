# Core/Execution.md

Load for day-to-day execution, especially when stack, process, or verification is unclear.

## Discovery order

Before changing anything:

1. Read the user request closely.
2. Read the local code or docs that already own the concern.
3. Check repo truth: lockfiles, CI, config, existing patterns.
4. Load what `Skills/Routing.md` mandates for the task -- `shiv-code-gate` for code and `caveman` for prose are not optional -- plus the matching domain skill.
5. Then edit.

Do not ask the user for facts you can discover locally.

## Interrogate before you write

For each new artifact you are about to add -- function, type, table, column, role, repo, helper, test, migration row, config field -- answer these in one line each. If you cannot, do not write it.

1. Purpose. What real behavior does this enable? Not "supports future X." Today.
2. Caller. Who invokes this? Show the actual call site or the request that triggered the need.
3. Authentication / entry path, if it crosses a trust boundary. How does a caller legitimately reach this? If the answer involves "we will figure out later how it gets called," stop.
4. Conflation check. Is this trying to serve two distinct purposes (system vs human, internal vs external, read vs write)? Split or pick one.
5. Deletion test. If I leave this out, what fails, and how loudly? If nothing fails, leave it out.
6. Smallest shape. Could this be a plain value, a column, or a function instead of a class, table, or subsystem?

This is the same interrogation a strong reviewer will run on the diff. Running it before you write saves the round trip.

## Scope discipline

Fix what the task asks for. Note adjacent issues; do not silently expand the diff to address them. A bug fix is not a refactor. A migration is not a redesign. Exception: a preparatory refactor that makes the feature diff smaller is in scope -- it lands as its own commit before the behavior change. If a related issue is real, log it and move on -- the LLM never finishes if it keeps fixing everything it sees.

## Ask vs proceed

Ask when:
- architecture could fork in multiple valid ways
- the choice affects more than one layer
- the task could burn an hour of rework if guessed wrong
- you are about to delete or replace significant existing behavior

When you ask, ask the single most load-bearing question -- one question, not a survey.

Proceed when:
- the choice is local and reversible
- the repo already made the pattern obvious
- the user said "your call"
- the assumption is narrow and you can state it clearly

## TDD and execution order

If the repo has tests, use the loop:

1. Write or identify the failing test.
2. Make the smallest change that passes.
3. Refactor with tests still green.

If the repo does not test that layer today, do not bolt on a new framework without cause. Follow the local pattern and add the lightest credible verification.

Default build order:
- contract first when the repo is contract-led
- otherwise core inward to outward: model, service, view

## History and checkpoints

If the directory is a real git repo, keep one concern per commit and commit before switching layers. If it is not a git repo, keep the same mental discipline and avoid mixing unrelated concerns in one edit pass.

## Verification before "done"

Do not claim completion until you have checked:

- the behavior changed for the intended reason
- tests or equivalent verification passed
- errors are explicit
- no new boundary violations appeared
- no stale references remain in docs you touched

## Stop conditions

Stop and surface it when:
- you hit a real blocker
- the task depends on a missing secret, service, or repo
- the instructions conflict
- repeated verification failures show the plan is wrong

Do not push through by guessing.
