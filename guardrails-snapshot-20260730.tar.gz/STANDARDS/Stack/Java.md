# Stack/Java.md

Load for Java or Quarkus work.

## Toolchain

- Use Maven.
- Respect the repo's existing formatter, test, and build setup.

## Structure and boundaries

Recommended split:
- `domain/` for entities and value objects
- `service/` for business logic
- `resource/` for HTTP resources
- `repository/` for persistence
- `config/` and `exception/` for framework concerns

Resources stay thin. Services own behavior.

## Types and contracts

- prefer clear domain types over annotation-heavy cleverness
- use interfaces when they create a real seam, not by ritual
- keep DTOs explicit at boundaries

## Error handling

- map domain or application failures to stable HTTP responses deliberately
- do not swallow exceptions
- keep exception mappers honest and specific

## Persistence

- repositories own query logic
- services do not reach around repositories into persistence details
- schema changes should remain backward-compatible across deploys

## Testing

- domain logic: pure unit tests
- service logic: unit tests with mocked edges
- resource and persistence paths: integration tests with real infrastructure when the repo already does that

## Anti-patterns

- annotation piles hiding weak design
- giant services
- resources doing business logic
- generic base classes that exist only to look enterprise

## Pre-commit check

- service/resource split is still clean
- exception mapping is explicit
- persistence is not leaking into presentation
- tests cover the changed path
