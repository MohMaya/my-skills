# Stack/Go.md

Load for Go work.

## Toolchain

- Use `go mod`.
- Respect the repo's formatter and test commands.
- Skills: `golang-code-style`, `golang-error-handling`.

## Types and interfaces

- keep interfaces consumer-side and small
- do not invent interface layers before there is a second implementation or a real seam
- prefer plain structs and functions

## Structure and boundaries

- domain types stay simple
- services own orchestration
- handlers stay thin
- repositories own database access

## Error handling

- return explicit errors
- wrap only when the extra context helps
- no error-wrapper hierarchies

## Context and concurrency

- pass `context.Context` through request and IO boundaries
- stop goroutines cleanly
- use channels and goroutines because they make the code clearer, not because Go has them

## Testing

- table-driven tests are fine when they help clarity
- integration tests use the real dependencies the repo already uses
- avoid mock-heavy tests for simple logic

## Data access

- keep query ownership obvious
- watch for connection leaks
- prefer boring query structure over clever abstraction

## Anti-patterns

- interface theater
- premature generics
- package sprawl for tiny features
- hidden concurrency

## Pre-commit check

- interfaces still earn their keep
- context flows correctly
- errors are actionable
- tests prove the changed behavior
