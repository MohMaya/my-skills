# Product/Architecture.md

Load for product-level architecture doctrine.

## Core posture

- Keep the system boring where it can be boring.
- Keep domain boundaries explicit.
- Prefer additive evolution over rewrites hidden inside feature work.

## Domain boundaries

- services and domains own their data and behavior
- cross-domain access goes through clear contracts
- no reach-through persistence access across boundaries

## Data classes

Keep the system honest about what kind of data it is handling:

- static reference data
- event data
- current state
- sensor or telemetry data
- logs and operational traces

Different classes have different retention, consistency, and query needs. Do not force one storage shape to act like all five.

## Event-sourced or history-sensitive systems

If the product uses event history or versioned entities:
- treat events as immutable
- keep write ordering explicit
- derive current state deliberately
- never hide mutation rules in the UI layer

## Identifiers

- internal identifiers should be stable and machine-friendly
- external identifiers should be safe to expose
- do not overload one identifier for every surface

## Service architecture

- commands and queries can diverge when it earns clarity
- async communication is useful when the domain and failure model justify it
- synchronous APIs still need clear ownership and timeout behavior
- BFF logic belongs in application services, not in presentation

## Runtime safety

- trunk-based development for product teams
- short-lived branches
- feature flags for risky or incomplete rollout paths
- rollback is a first-class design concern

## Caching and consistency

Cache with intent.

- explicit invalidation for mutable data
- versioned cache keys
- clear ownership of cache policy
- do not pretend TTL alone is a strategy

## Deployment baseline

Assume:
- automated quality gates
- structured logs
- metrics and traces where they matter
- deploys that can be rolled forward or rolled back safely

## Modular repo posture

Shared types belong in shared modules. Feature-internal types stay internal. Do not let convenience collapse the repo into hidden coupling.

## Divergence protocol

If you need to diverge from an architectural standard:

1. document the divergence in an ADR
2. state what changed
3. state blast radius
4. get explicit approval
5. set a review date

Never drift silently.
