# Skills/Routing.md

Load when a skill could help. Inventory lives in `Skills/Catalog.md`; the runtime's available-skills list is the source of truth for what is loadable right now.

## Mandates -- not optional, not on request

- `shiv-code-gate` on every code change (ladder + Structure Note gate + accounting).
- `simplify` as the subtractive final pass before every commit/PR.
- `caveman` on every non-code output.
- `grilling` at least once before any ticket is filed or body of work starts -- once per piece of work, not per session.
- Specs publish through `to-spec`, tickets through `to-tickets`, PRDs through `writing-prds`. Never hand-write any of them into a tracker.
- `caveman-commit` for every commit message.
- `security-review` on auth-touching code and before any launch.

## Default routes

| Situation | Skill |
| --------- | ----- |
| Stress-testing a plan or decision | `grilling` (`grill-with-docs` when ADRs should fall out) |
| Work too big for one session | `wayfinder` |
| Implementing from spec/tickets | `implement` |
| Review before merge | `code-review`; `ponytail-review` for bloat; comments in `caveman-review` form |
| Closing out a diff | `simplify` -- mandatory subtractive pass |
| Grilling touches module shape or boundaries | `codebase-design` for the structural questions |
| Hard bugs, perf regressions | `diagnosing-bugs` |
| Merge/rebase conflicts | `resolving-merge-conflicts` |
| Stacked branches, dependent PRs | `gh-stack` |
| Module/interface design | `codebase-design`, `design-an-interface`, `domain-modeling` |
| E2E or browser testing | `playwright-best-practices` via `playwright-cli` |
| Postgres | `supabase-postgres-best-practices` |
| Railway backend | `use-railway` |
| Expo / React Native | `expo-native-ui`, `expo-router`; ship via `eas-workflows`, `eas-app-stores` |
| LLM features | `ai-sdk` (TS), `claude-api` (Anthropic) |
| New UI, screens, or design direction | `frontend-design` + `design-taste-frontend` (mandatory taste pass); `high-end-visual-design` for premium surfaces |
| Figma design → code | `figma:figma-design-to-code`; `extract-design-system` to formalize the design system first |
| Code or description → Figma | `figma:figma-generate-design` (screens/views), `figma:figma-generate-library` (design system), `figma:figma-use` before any `use_figma` call |
| UI polish and motion | `emil-design-eng`, `apple-design`, animation family |
| Marketing copy, GTM, pricing | `product-marketing` context first, then `copywriting` / `positioning` / `pricing` |
| Composed writing | `writing-fragments` → `writing-shape` → `edit-article` |
| Session ending mid-work | `handoff` |
| Can't find the right skill | `find-skills` |

## Invocation contract

- Prefer the smallest useful set: one process skill, one domain skill, one polish skill if needed. No overlapping loads.
- Skip a matching skill only with a stated reason. Mandates cannot be skipped.
- Never route to a skill you cannot see in the runtime or verify on disk; fuzzy match → `find-skills`.
