# Skills/Catalog.md

Approved inventory, verified on disk (75 skills, all under `~/.agents/skills/`). The runtime's available-skills list is authoritative for what is loadable right now.

## Always-on mandates

| Family | Skills | Enforcement |
| ------ | ------ | ----------- |
| ponytail | `ponytail`, `ponytail-review`, `ponytail-audit`, `ponytail-debt`, `ponytail-gain`, `ponytail-help` | `ponytail` on every code change; the rest on demand |
| caveman | `caveman`, `caveman-commit`, `caveman-review`, `caveman-compress`, `caveman-stats`, `caveman-help`, `cavecrew` | `caveman` on every non-code output; `caveman-commit` on every commit |

## Workflow spine

| Skill | Use when |
| ----- | -------- |
| `grilling` / `grill-me` / `batch-grill-me` / `grill-with-docs` | stress-testing a plan -- mandatory once before any ticket or body of work |
| `to-spec` | publishing a spec from the conversation |
| `to-tickets` | breaking work into tracker tickets |
| `writing-prds` | PRDs |
| `wayfinder` | work too big for one session |
| `implement` | executing from a spec or tickets |
| `handoff` | session ending mid-work |

## Engineering

`code-review`, `tdd`, `diagnosing-bugs`, `resolving-merge-conflicts`, `prototype`, `research`, `security-review`, `gh-stack` (stacked branches and dependent PRs via the `gh stack` CLI extension)

## Architecture

`codebase-design`, `design-an-interface`, `domain-modeling`, `improve-codebase-architecture`

## Stack

| Skill | Use when |
| ----- | -------- |
| `supabase-postgres-best-practices` | Postgres schema, queries, tuning |
| `fastapi` | FastAPI/Python API work |
| `golang-code-style`, `golang-error-handling` | Go |
| `use-railway` | Railway services, jobs, deploys, env |
| `ai-sdk` | LLM features in TS (Vercel AI SDK) |
| `claude-api` | Anthropic API specifics (built-in) |
| `playwright-cli`, `playwright-best-practices` | E2E and browser testing |
| `vercel-optimize` | Vercel cost/perf |

## Frontend and motion

Taste (mandatory on new UI): `frontend-design`, `design-taste-frontend`, `high-end-visual-design`; `extract-design-system` to formalize tokens from chosen designs.

Figma (figma plugin, Claude Code): `figma:figma-design-to-code` for design → code; `figma:figma-generate-design` for code/description → Figma screens; `figma:figma-generate-library` for building design systems in Figma; `figma:figma-use` is a mandatory prerequisite before any `use_figma` call; `figma:figma-implement-motion` and `figma:figma-code-connect` where relevant.

Polish and compliance: `emil-design-eng`, `apple-design`, `web-design-guidelines`, `vercel-react-best-practices`, `vercel-composition-patterns`, `vercel-react-view-transitions`, `animation-vocabulary`, `find-animation-opportunities`, `improve-animations`, `review-animations`

## Mobile

`expo-native-ui`, `expo-router`, `eas-workflows`, `eas-app-stores`, `vercel-react-native-skills`

## Product and GTM

`writing-prds`, `positioning`, `pricing`, `product-marketing`, `copywriting`

## Writing

`writing-fragments` (explore) → `writing-beats` / `writing-shape` (exploit) → `edit-article` (revise); `writing-guidelines` for review

## Meta

`find-skills`, `teach`, `writing-great-skills`
